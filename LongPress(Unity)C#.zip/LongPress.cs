﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Long push button.ボタン長押し
/// </summary>
public class LongPushButton : MonoBehaviour {


	/// Button に EventTrigger を　二種類つけてください。

	/// <summary>
	/// The check. 押している間　true
	/// </summary>
	public bool check;

	/// <summary>
	/// The time. 押している間　時間経過
	/// </summary>
	public float time;

	/// <summary>
	/// Pointers down. EventTrigger にて　PointerDown 
	/// </summary>
	public void PointerDown(){

		check = true;
	}
	/// <summary>
	/// Pointers up. EventTrigger にて　PointerUp
	/// </summary>
	public void PointerUp(){

		check = false;

	}
	/// <summary>
	/// Update this instance. Time関数　と Mathf関数
	/// </summary>
	void Update(){

		///check が　true の時
		if (check == true) {
			// 時間がプラス
			time += Time.deltaTime;

			//そうでない時
		} else {

			//時間が経過するよりも二倍の早さでマイナスに
			time -= Time.deltaTime*2;

			//time は　0以下には絶対にならないよという命令
			//常に　数字が大きい方を出力
			time = Mathf.Max (0, time);

		}
	}


}  
	